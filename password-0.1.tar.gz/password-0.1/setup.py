from setuptools import setup

setup(
    name='password',
    version='0.1',
    description='Collection of password and api class',
    author='Kacper Turek',
    packages=['password_package'],
    install_requires=['requests']
)